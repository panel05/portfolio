package halal_labirintus;

import java.util.Random;
import java.util.Scanner;

public class Halal_Labirintus {
    public static void main(String[] args) {
        Random rnd = new Random();
        int uggyesseg = 6 + rnd.nextInt(6)+1;
        int eletero = 12 + rnd.nextInt(11)+2;
        int szerencse = 6 + rnd.nextInt(6)+1;
        
        int arany = 0;
        String targyak = "";
        
        Scanner sc = new Scanner(System.in);
        System.out.println("A harcos neve: \n");
        String nev = sc.nextLine(); //így lesz string a user input
        
        
        /*Karakterlap kiírása*/
        System.out.println("\n*** KARAKTERLAP ***");
        System.out.println("Név: " + nev);
        System.out.printf("Ügyesség: %d, Életerő: %d, Szerencse: %d\n", uggyesseg, eletero, szerencse);
        System.out.printf("Arany: %d\n", arany);
        System.out.println("Tárgyak: \n" + targyak);
        System.out.println("-------------------------------------\n");
        
        /*oldalak*/
        
        String oldal_1, oldal_56, oldal_66, oldal_137, oldal_215, oldal_270, oldal_293, oldal_373, oldal_387;
        
        System.out.println("Egy versenyre nevezel, aminek a lényege, hogy át kell kelni a halállabirintuson.\n A labirintusban tárgyakat találhatsz és szörnyekkel kell harcoljál.");
        
        oldal_1 = "Miután öt percet haladtál lassan az alagútban, egy kőasztalhoz érsz, amely a bal oldali fal mellett áll.\n Hat doboz van rajta, egyikükre a te neved festették."
                +"\nHa ki akarod nyitni a ládát "
                +"\n\tLapozz a 270-re"
                +"\n\tHa inkább tovább haladsz észak felé"
                +"\n\tLapozz a 66-ra";
        
        oldal_56 = "Látod, hogy az akadály egy széles, barna, sziklaszerű tárgy.\n Megérinted, és meglepve tapasztalod, hogy lágy, szivacsszerű."
                +"\n Ha átszernél rajta mászni"
                +"\n\tLapozz a 373-ra"
                +"\n\tHa ketté akarod vágni a kardoddal"
                +"\n\tLapozz a 215-re";
        
        oldal_66 = "Néhány perc gyaloglás után egy elágazáshoz érsz az alagútban. Egy, a falra festett fehér nyíl nyugatfelé mutat.\n A földön nedves lábnyomok jelzik, merre haladtak az előtted járók.\n Nehéz biztosan megmondani, de úgy tűnik, hogy három közülük a nyíl irányába halad, míg egyikük úgy döntött, hogy keletnek megy."
                +"\nHa nyugat felé kivánsz menni"
                +"\n\t Lapozz a 293-ra"
                +"\n\tHa keletnek"
                +"\n\tLapozz a 56-ra";
        oldal_137 = "Ahogy végigmész az alagúton, csodálkozva látod, hogy egy jókora vasharang csüng alá a boltozatról.";
        
        oldal_215 = "Kardod könnyedén áthatol a spóragolyó vékonykülső burkán. Sűrű barna spórafelhő csap ki a golyóból, és körülvesz.\nNémelyik spóra a bőrödhöz tapad, és rettenetes viszketést okoz.\nNagy daganatok nőnek az arcodon és karodon, és a bőröd mintha égne.\n2 ÉLETERŐ pontot veszítesz. Vadul vakarózva átléped a leeresztett golyót, és keletnek veszed az utad.";
        
        oldal_270 = "A doboz teteje könnyedén nyílik. Benne két aranypénzt találsz, és egy üzenetet, amely egy kis pergamenen neked szól. Előbb zsebre vágod az aranyakat, aztán elolvasod az üzenetet: - „Jól tetted.\nLegalább volt annyi eszed, hogy megállj és elfogadd az ajándékot.\nMost azt tanácsolom neked, hogy keress és használj különféle tárgyakat, ha sikerrel akarsz áthaladni Halállabirintusomon.” Azaláírás Szukumvit.\nMegjegyzed a tanácsot, apródarabokra téped a pergament, és tovább mészészak felé."
                  +"\nLapozz a 66-ra";
        
        oldal_293 = "A három pár nedves lábnyomot követve az alagútnyugati elágazásában hamarosan egy újabb el-ágazáshoz érsz."
                  +"\nHa tovább mész a lábynomokat követve"
                +"\n\tLapozza 137-re"
                +"\n\tHa inkább észak felé mész a harmadik lábnyom után"
                +"\n\tLapozza 387-re";
        oldal_373 = "Fölmászol a lágy sziklára, attól tartasz, hogy bár-melyik pillanatban elnyelhet.\nNehéz átvergődni rajta, mert puha anyagában alig tudod a lábadat emelni, de végül átvergődsz rajta.\nMegkönnyebbülten érsz újra szilárd talajra, és fordulsz kelet felé.";
        
        oldal_387 = "Hallod, hogy elölről súlyos lépések közelednek. Egy széles, állatbőrökbe öltözött, kőbaltás, primitívlény lép elő.\nAhogy meglát, morog, a földre köp, majd a kőbaltát felemelve közeledik, és mindennek kinéz, csak barátságosnak nem.\nElőhúzod kardodat, és felkészülsz, hogy megküzdj a Barlangi Emberrel.";
        
        /*első oldal*/
        System.out.println(oldal_1);
        
        System.out.println("Oldal: ");
        String oldal = sc.nextLine();
        
        if(oldal.equals("270")){
            System.out.println(oldal_270);
            arany += 2;
            System.out.println(oldal_66);
            System.out.println("Oldal:");
            oldal = sc.nextLine();
            if(oldal.equals("56")){
                System.out.println(oldal_56);
                System.out.println("Oldal: ");
                oldal = sc.nextLine();
                if(oldal.equals("215")){
                    System.out.println(oldal_215);
                }else if(oldal.equals("373")){
                    System.out.println(oldal_373);
                }
                if(oldal.equals("137")){
                    System.out.println(oldal_137);
                }else if(oldal.equals("387")){
                    System.out.println(oldal_387);
                }     
            }else if(oldal.equals("293")){
                System.out.println(oldal_293);
                System.out.println("Oldal: ");
                oldal = sc.nextLine();
                if(oldal.equals("137")){
                    System.out.println(oldal_137);
                }else if(oldal.equals("387")){
                    System.out.println(oldal_387);
                }
            }
        }else if(oldal.equals("66")){
            System.out.println(oldal_66);
            System.out.println("Oldal: ");
            oldal = sc.nextLine();
            if(oldal.equals("56")){
                System.out.println(oldal_56);
                System.out.println("Oldal: ");
                oldal = sc.nextLine();
                if(oldal.equals("215")){
                    System.out.println(oldal_215);
                    eletero -= 2;
                }else if(oldal.equals("373")){
                    System.out.println(oldal_373);
                }
            }else if(oldal.equals("293")){
            System.out.println(oldal_293);
            System.out.println("Oldal: ");
            oldal = sc.nextLine();
            if(oldal.equals("137")){
                System.out.println(oldal_137);
                System.out.println("");
            }else if(oldal.equals("387")){
                System.out.println(oldal_387);
                System.out.println("");
            }
        }
        }
        /*Karakterlap játék után*/
        System.out.println("***********Karakterlap***********");
        System.out.println("Játékos neve: " + nev);
        System.out.printf("Ügyesség: %d Életerő: %d Szerencse: %d\n", uggyesseg, eletero, szerencse );
        System.out.println("Pénz, drágakő: ");
        System.out.printf("\tarany: %d\n", + arany);
        System.out.println("Tárgyak listája: \n");
        System.out.println("--------------------------------------------------------------");
    }
    
}
